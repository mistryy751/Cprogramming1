/*Take the price and quantity of items as an input. Write a C function to
calculate the sum of the prices. Write another C function to calculate the
discount according to the following rules: For a total less than Rs.1000,
discount is 5%. For a total greater than Rs.1000 but less than Rs.5000,
discount is 10%. For a total greater than Rs.5000, discount is 15%. Write
another function to print the individual item prices, total, discount and the
final price.*/
#include<stdio.h>
#include<conio.h>
int dis(int);
int final(int,int,int);
int main()
{
int price, quant,sum1;
printf("enter price and qunatity of items");

scanf("%d  %d ", &price, &quant);

sum1=price * quant;
dis(sum1);

return 0;

}

//Function for calculate discount
int dis(sum1)
{
    int sum,d;

if( sum< 1000)

{
            d = (sum * 5) / 100;

            sum = sum - d;

}

else if(sum>1000 && sum<5000)

{
            d = (sum * 10) / 100;

            sum = sum - d;

}

else if( sum>5000)

{
            d = (sum * 15) / 100;

            sum = sum - d;

}
final(d,sum,sum1);
return d,sum;

}

//Function for Final Display
int final (sum1,sum,d)
{


printf(" total price %d \n", sum1);
printf ("final price =%d  discount=%d", sum, d);
return 0;

}
    
    