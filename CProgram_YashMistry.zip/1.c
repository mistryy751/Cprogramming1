/*Write a program to print your name and address*/
#include<stdio.h>
#include<conio.h>
int main()
{
    printf("Name: Mistry Yash Prakashbhai \n");
    printf("\nAddress: Surat,Gujarat,India");
    return 0;
    getch();

}
